#ifndef poly_h
#define poly_h


/*
 * A struct with data that can represent a polynomial term */
typedef struct term_t term_t;


/*
 * A struct with data that can represent a polynomial expression
 */
typedef struct poly_t poly_t;


/*
 * Creates a new polynomial from a string, e.g. "x^30 - 42x + 5"
 */
poly_t* new_poly_from_string(const char*);


/*
 * Prints the entire polynomial as a string.
 * Returns nothing.
 */
void print_poly(poly_t*);


/*
 * Multiplicates two poly_t structs and returns the result as a pointer
 */
poly_t* mul(poly_t*, poly_t*);


/*
 * Frees memory allocated for poly_t
 */
void free_poly(poly_t*);




/* ---------------- Below functions are only used in poly.c ---------------- */


/*
 * Called when the program finds a digit, that is not in the exponent.
 * Reads the string until it finds a "power" sign (^), return coefficient.
 */
int make_coef(const char* term_s, int s);


/*
 * Called after the program finds a '^' character, and then takes the rest of
 * the term and creates an exponent from it. Returns the exponent as an int.
 */
int make_exp(const char* term_s, int s);


#endif
