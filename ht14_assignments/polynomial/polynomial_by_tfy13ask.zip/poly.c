/*
 * polynomial
 * Assignment 3 - EDAA25 (C programming)
 * Author: Alexander Skafte
 * Personal identity number: 941123-4330
 * email: tfy13ask@student.lu.se
 */

/*
 * The program compiles, but produces some runtime error(s). I cannot find why.
 * I probably need to implement better error checking, and more checks for
 * special cases. My make_coeff(...) method is probably stupid - I would be
 * grateful for feedback on how to cut/create/handle strings more effectively.
 */

#include <assert.h>
#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "error.h"
#include "poly.h"

#define MAX_TERMS (20)

struct term_t {
	signed char	sign;
	int		coef;
	int		exp;
};

struct poly_t {
	term_t	terms[MAX_TERMS];
	int	n_terms;
};

poly_t* new_poly_from_string(const char* poly_str)
{
	poly_t*		poly;	/* The polynomial to be returned */
	const char*	term_s;	/* String that will represent a term */

	int		s;	/* Keeps track of location inside term_s */
	int		t;	/* Keeps track of which term is being created */
	bool		add_term;

	poly = (poly_t*) malloc(sizeof(poly));
	assert(poly != NULL);

	s = 0;
	t = 0;

	char str[sizeof(poly_str)];	/** Make a copy of poly_str, truncate */
	strcpy(str, poly_str);		/* it with strtok and assign strtok's */
	term_s = strtok(str, " ");	/* return value to term_s.	     **/

	while (term_s != NULL) {

		poly->terms[t].sign = 1;

		while (term_s[s] != ' ' || term_s[s] != '\0') {

			if (term_s[s] == '+' || term_s[s] == '-') {
				if (term_s[s] == '+')
					poly->terms[t].sign = +1;
				else
					poly->terms[t].sign = -1;
				add_term = false;
			} else {
				add_term = true;
			}

			if (isalpha(term_s[s])) {
				poly->terms[t].coef = 1;
			}

			if (isdigit(term_s[s])) {
				poly->terms[t].coef = make_coef(term_s, s);
			}

			if (term_s[s] == '^') {
				poly->terms[t].exp = make_exp(term_s, s);
			}

			s++;
		}
		printf("term_s = \"%s\"\n", term_s);
		term_s = strtok(NULL, " ");
		s = 0;
		if (add_term)
			t++;
	}
	poly->n_terms = t;
	return poly;
}

void print_poly(poly_t* poly)
{
	signed char	sign;
	int 		coef;
	int		exp;
	int		t;

	printf("\nprint_poly(poly_t*):\n");

	for (t = 0; t < MAX_TERMS; ++t) {
		sign 	= poly->terms[t].sign;
		coef	= poly->terms[t].coef;
		exp	= poly->terms[t].exp;		

		if (exp == 0)
			printf("%d", coef);
		else if (coef == 1)
			printf("x^%d ", exp);
		else
			printf("%dx^%d ", sign * coef, exp);
	}
	printf("\n");
}

poly_t* mul(poly_t* p, poly_t* q)
{
	poly_t* r;	/* poly_t* to return */
	int 	i, j;	/* for loop variables */
	int	t;	/* (temp) Holds number of terms in return polynomial */

	r = (poly_t*) malloc(sizeof(poly_t));
	assert(r != NULL);

	r->n_terms = 0;
	t = r->n_terms;

	for (i = 0; i < p->n_terms; ++i) {
		for (j = 0; j < q->n_terms; ++j) {
			r->terms[t].sign = p->terms[t].sign * q->terms[t].sign;
			r->terms[t].coef = p->terms[t].coef * q->terms[t].coef;
			r->terms[t].exp = p->terms[t].exp * q->terms[t].exp;
			t++;
		}
	}
	r->n_terms = t;

	return r;
}

void free_poly(poly_t* poly)
{
	assert(poly != NULL);
	assert(poly->terms != NULL);

	free(poly->terms);
	free(poly);
}

int make_coef(const char *term_s, const int s)
{
	char	str[64] = { '$' }; /* The '$' char is used in strtok later */
	int	i;

	/* End before '^' (if has exponent) or '\0' (if has no exponent) */
	for (i = 0; term_s[s + i] != '^' || term_s[s + i] != '\0'; ++i)
		str[i] = term_s[s + i];

	strtok(str, "$");

	return atoi(str);
}

int make_exp(const char *term_s, const int s)
{
	char	str[strlen(term_s) - s];
	char	exp_sign = 1;
	int 	i;

	if (str[0] == '-')
		exp_sign = -1;

	/* This loop is probably bad and wrong... */
	for (i = 0; term_s[s] != ' ' || term_s[s] != '\0'; ++i)
		str[i] = term_s[s + i];

	return (exp_sign * atoi(str));
}
